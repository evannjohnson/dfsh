#!/bin/bash

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"

mkdir "$SCRIPT_DIR/machine-a" && cd "$SCRIPT_DIR/machine-a"
echo "
export DFSH_REPO=\"$SCRIPT_DIR/machine-a/.dotfiles\"
export DFSH_WORK=\"$SCRIPT_DIR/machine-a\"
" >> env-vars
source env-vars
dfsh clone ../dotfiles-repo-remote
dfsh checkout a

mkdir ../machine-b && cd ../machine-b
echo "
export DFSH_REPO=\"$SCRIPT_DIR/machine-b/.dotfiles\"
export DFSH_WORK=\"$SCRIPT_DIR/machine-b\"
" >> env-vars
source env-vars
dfsh clone ../dotfiles-repo-remote
dfsh checkout b
